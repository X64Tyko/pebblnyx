#include "pnx_text.h"

#if PNX_USE_TEXT

#include "pnx_gfx.h" // pnx_bw_is_ink / pnx_bw_set_pixel, shared with the 1-bit blitter

// A depth=2 glyph's runtime colours: level 1 (outline), 2 (fill A) and 3 (fill B) each get
// their own, baked into the levels at pipeline time rather than blended per pixel (see
// rasterise_glyph_styled / glyph_overrides in pnx_assets.py). Level 0 is transparent and
// never reaches a span writer. Not part of the public API -- draw_glyph builds one from a
// single colour for the plain draw calls, and only pnx_text_draw_gradient_outlined lets a
// caller supply the three colours directly.
typedef struct
{
	uint8_t outline;
	uint8_t fill_a;
	uint8_t fill_b;
} PnxTextPalette;

// --------------------------------------------------------------------------- spans
//
// One glyph row into one framebuffer row, clipped against the row's own reported span
// rather than the target width -- a round display narrows [min_x, max_x] per row, and
// assuming a rectangle is what breaks there. Same contract as span_4bpp in pnx_gfx.c.

#if !PNX_DISPLAY_BW

static void span_1bpp(uint8_t* row_base, int32_t x, const uint8_t* line, uint8_t colour,
					  int32_t w, int16_t min_x, int16_t max_x)
{
	int32_t i0 = 0, i1 = w;
	if (x + i0 < min_x)
		i0 = min_x - x;
	if (x + i1 > max_x + 1)
		i1 = max_x + 1 - x;
	if (i1 <= i0)
		return;

	uint8_t* dst = row_base + x;
	for (int32_t i = i0; i < i1; i++)
	{
		// MSB first: pixel i is bit 7 - (i & 7) of byte i >> 3.
		if (line[i >> 3] & (uint8_t)(0x80u >> (i & 7)))
			dst[i] = colour;
	}
}

// depth=2's whole meaning: a 2-bit index per pixel selecting one of three baked colours,
// never a blend. 0 is transparent and skipped; 1..3 look the palette up directly.
static void span_2bpp_styled(uint8_t* row_base, int32_t x, const uint8_t* line,
							 const PnxTextPalette* pal, int32_t w, int16_t min_x,
							 int16_t max_x)
{
	int32_t i0 = 0, i1 = w;
	if (x + i0 < min_x)
		i0 = min_x - x;
	if (x + i1 > max_x + 1)
		i1 = max_x + 1 - x;
	if (i1 <= i0)
		return;

	uint8_t* dst = row_base + x;
	for (int32_t i = i0; i < i1; i++)
	{
		const uint8_t level = (uint8_t)((line[i >> 2] >> (6 - 2 * (i & 3))) & 3u);
		if (level == 0)
			continue; // transparent, the common case
		dst[i] = (level == 1) ? pal->outline : (level == 2) ? pal->fill_a
															: pal->fill_b;
	}
}

#endif // !PNX_DISPLAY_BW

#if PNX_DISPLAY_BW

// 1-bit target versions of the two span writers above. Same coverage tests, same clipping
// contract -- only the destination write differs, a framebuffer bit (pnx_bw_set_pixel,
// pnx_gfx.h) instead of a GColor8 byte, and `colour` is resolved to ink-or-paper ONCE by
// the caller rather than per pixel, same as pnx_gfx_fill_rect's 1-bit path.

static void bw_span_1bpp(uint8_t* row_base, int32_t x, const uint8_t* line, bool ink,
						 int32_t w, int16_t min_x, int16_t max_x)
{
	int32_t i0 = 0, i1 = w;
	if (x + i0 < min_x)
		i0 = min_x - x;
	if (x + i1 > max_x + 1)
		i1 = max_x + 1 - x;
	if (i1 <= i0)
		return;

	for (int32_t i = i0; i < i1; i++)
	{
		// MSB first: pixel i is bit 7 - (i & 7) of byte i >> 3, same as the colour-target
		// span_1bpp above -- this is the glyph's own coverage bitmap, unrelated to the
		// LSB-first framebuffer bit pnx_bw_set_pixel writes on the other end.
		if (line[i >> 3] & (uint8_t)(0x80u >> (i & 7)))
			pnx_bw_set_pixel(row_base, x + i, ink);
	}
}

// A 1-bit target has no room for three colours, so any non-transparent level -- outline or
// either fill -- draws ink. That is the glyph's own silhouette (outline ring union filled
// interior), which is the one thing a monochrome watch can still show of a styled glyph.
static void bw_span_2bpp_styled(uint8_t* row_base, int32_t x, const uint8_t* line, bool ink,
								int32_t w, int16_t min_x, int16_t max_x)
{
	int32_t i0 = 0, i1 = w;
	if (x + i0 < min_x)
		i0 = min_x - x;
	if (x + i1 > max_x + 1)
		i1 = max_x + 1 - x;
	if (i1 <= i0)
		return;

	for (int32_t i = i0; i < i1; i++)
	{
		const uint8_t level = (uint8_t)((line[i >> 2] >> (6 - 2 * (i & 3))) & 3u);
		if (level != 0)
			pnx_bw_set_pixel(row_base, x + i, ink);
	}
}

#endif // PNX_DISPLAY_BW

// ---------------------------------------------------------------------- direction
//
// Layout happens in the font's own frame -- advances along the baseline, line_height
// across it -- and lands in the framebuffer's. For a portrait face the two are the same
// frame and every one of these is the identity; for a landscape build, whose glyphs were
// rotated when they were baked, the pen runs down a column and lines stack sideways.
//
// Kept as three small functions rather than a matrix because that is all it is: two unit
// vectors and a corner. A matrix would cost multiplies per glyph to express the same
// four cases, and a switch on a value that never changes within a string predicts
// perfectly.

// True when the pen runs down a column, which is every landscape build and would be a
// vertical script.
static inline bool axis_vertical(uint8_t axis)
{
	return axis == PNX_ADVANCE_Y_POS || axis == PNX_ADVANCE_Y_NEG;
}

// Which way the pen moves between glyphs, along its own axis.
static inline int32_t pen_sign(uint8_t axis)
{
	return (axis == PNX_ADVANCE_Y_NEG || axis == PNX_ADVANCE_X_NEG) ? -1 : 1;
}

// Which way successive lines stack, across the baseline. Only one case runs backwards:
// with the pen going down a column, "below the baseline" is towards smaller x.
static inline int32_t base_sign(uint8_t axis)
{
	return axis == PNX_ADVANCE_Y_POS ? -1 : 1;
}

// A caller's (x, y) is a point in the framebuffer either way. Which of the two is the pen
// and which is the baseline depends on the axis, and that is the whole of the conversion.
static inline void split_origin(uint8_t axis, int32_t x, int32_t y, int32_t* pen, int32_t* base)
{
	if (axis_vertical(axis))
	{
		*pen  = y;
		*base = x;
	}
	else
	{
		*pen  = x;
		*base = y;
	}
}

// Top-left corner of a glyph's STORED bitmap, from a pen position on the baseline.
//
// `pen` runs along the baseline and `base` is the baseline's own coordinate on the other
// axis -- so for a portrait font they are x and y, and for a rotated one they are y and
// x. Where the bitmap runs backwards from the pen, its extent comes off the corner: that
// is the -1 in each of the rotated cases, which is the difference between a glyph sitting
// on the baseline and one hanging off the wrong side of it.
static inline void glyph_origin(uint8_t axis, const PnxGlyph* g, int32_t pen, int32_t base,
								int32_t* out_x, int32_t* out_y)
{
	switch (axis)
	{
		case PNX_ADVANCE_Y_POS:
			*out_x = base + g->bearing_y - g->w + 1;
			*out_y = pen + g->bearing_x;
			break;
		case PNX_ADVANCE_Y_NEG:
			*out_x = base - g->bearing_y;
			*out_y = pen - g->bearing_x - g->h + 1;
			break;
		case PNX_ADVANCE_X_NEG:
			*out_x = pen - g->bearing_x - g->w + 1;
			*out_y = base - g->bearing_y;
			break;
		default:
			*out_x = pen + g->bearing_x;
			*out_y = base - g->bearing_y;
			break;
	}
}

// One glyph at a pen position, one solid colour. `pen` is along the baseline and `base` is
// across it: x and y respectively for a portrait font, the other way round for a rotated
// one. A depth=2 glyph drawn this way flattens its baked levels to one colour -- every
// non-transparent pixel painted `colour` -- which is what a caller gets from the
// single-colour API (pnx_text_draw, pnx_text_draw_outlined's dynamic path,
// pnx_text_draw_wrapped) whether or not the font underneath carries baked levels; only
// draw_glyph_pal below keeps them distinct.
static void draw_glyph(PnxTarget* t, const PnxFont* f, const PnxGlyph* g, int32_t pen,
					   int32_t base, uint8_t colour)
{
	if (!g->bits)
		return; // a space: advance only

	int32_t x, y;
	glyph_origin(f->advance, g, pen, base, &x, &y);
	const int16_t th	 = pnx_target_height(t);
	const uint8_t stride = pnx_font_row_bytes(f, g->w);
#if PNX_DISPLAY_BW
	const bool ink = pnx_bw_is_ink(colour);
#endif

	int32_t j0 = 0, j1 = g->h;
	if (y < 0)
		j0 = -y;
	if (y + g->h > th)
		j1 = th - y;

	for (int32_t j = j0; j < j1; j++)
	{
		PnxRow row = pnx_target_row(t, (int16_t)(y + j));
		if (!row.data)
			continue;

		const uint8_t* line = g->bits + (uint32_t)j * stride;
		if (f->depth == 1)
		{
#if PNX_DISPLAY_BW
			bw_span_1bpp(row.data, x, line, ink, g->w, row.min_x, row.max_x);
#else
			span_1bpp(row.data, x, line, colour, g->w, row.min_x, row.max_x);
#endif
		}
		else
		{
#if PNX_DISPLAY_BW
			bw_span_2bpp_styled(row.data, x, line, ink, g->w, row.min_x, row.max_x);
#else
			const PnxTextPalette pal = { colour, colour, colour };
			span_2bpp_styled(row.data, x, line, &pal, g->w, row.min_x, row.max_x);
#endif
		}
	}
}

// Same as draw_glyph, but keeps a depth=2 glyph's baked levels distinct -- outline, fill A,
// fill B -- instead of flattening them to one colour. The caller (only
// pnx_text_draw_gradient_outlined) guarantees f->depth == 2; a depth=1 font has no third
// level to distinguish and never reaches here.
static void draw_glyph_pal(PnxTarget* t, const PnxFont* f, const PnxGlyph* g, int32_t pen,
						   int32_t base, const PnxTextPalette* pal)
{
	if (!g->bits)
		return; // a space: advance only

	int32_t x, y;
	glyph_origin(f->advance, g, pen, base, &x, &y);
	const int16_t th	 = pnx_target_height(t);
	const uint8_t stride = pnx_font_row_bytes(f, g->w);
#if PNX_DISPLAY_BW
	// A 1-bit target has no colours to distinguish; draw_glyph's own depth=2 branch above
	// resolves the same way, against the outline colour -- an outline reads as the "is this
	// glyph dark-on-light or light-on-dark" choice more often than either fill would.
	const bool ink = pnx_bw_is_ink(pal->outline);
#endif

	int32_t j0 = 0, j1 = g->h;
	if (y < 0)
		j0 = -y;
	if (y + g->h > th)
		j1 = th - y;

	for (int32_t j = j0; j < j1; j++)
	{
		PnxRow row = pnx_target_row(t, (int16_t)(y + j));
		if (!row.data)
			continue;

		const uint8_t* line = g->bits + (uint32_t)j * stride;
#if PNX_DISPLAY_BW
		bw_span_2bpp_styled(row.data, x, line, ink, g->w, row.min_x, row.max_x);
#else
		span_2bpp_styled(row.data, x, line, pal, g->w, row.min_x, row.max_x);
#endif
	}
}

// ------------------------------------------------------------------------ measuring

static inline int16_t glyph_advance(const PnxFont* f, char c)
{
	PnxGlyph g;
	pnx_font_glyph(f, pnx_font_glyph_index(f, c), &g);
	return g.advance;
}

// Width of [s, end). Used by both the measure calls and by alignment, so a centred line
// can never be centred against a width the draw does not produce.
static int16_t width_range(const PnxFont* f, const char* s, const char* end)
{
	int32_t w = 0;
	for (const char* p = s; p < end && *p; p++)
		w += glyph_advance(f, *p);
	return (int16_t)w;
}

int16_t pnx_text_width(const PnxFont* f, const char* s)
{
	if (!f || !s)
		return 0;
	int32_t w = 0;
	for (const char* p = s; *p && *p != '\n'; p++)
		w += glyph_advance(f, *p);
	return (int16_t)w;
}

// --------------------------------------------------------------------------- wrap

typedef struct
{
	const char* end;  // one past the last character to DRAW on this line
	const char* next; // where the following line starts
} PnxLineBreak;

// Finds the next line break at width `w`.
//
// Three cases, in priority order: an explicit '\n'; the last space before the overrun;
// and -- when a single word is wider than the box -- a hard break at the character that
// would have overflowed. The hard break matters more than it looks: without it a long
// word runs out of a dialogue box and over the art, which reads as a rendering bug.
//
// Always consumes at least one character, so a glyph wider than the whole box cannot
// spin the caller forever.
static PnxLineBreak next_line(const PnxFont* f, const char* s, int16_t w)
{
	const char* last_space = NULL;
	int32_t width		   = 0;

	for (const char* p = s; *p; p++)
	{
		if (*p == '\n')
		{
			PnxLineBreak br = { p, p + 1 };
			return br;
		}

		const int32_t adv = glyph_advance(f, *p);
		if (w > 0 && width + adv > w && p != s)
		{
			const char* end	 = last_space ? last_space : p;
			const char* next = last_space ? last_space + 1 : p;
			// Collapse the run of spaces at the break, so a wrapped line does not start
			// indented by whatever happened to follow the break point.
			while (*next == ' ')
				next++;
			PnxLineBreak br = { end, next };
			return br;
		}

		if (*p == ' ')
			last_space = p;
		width += adv;
	}

	const char* end = s;
	while (*end)
		end++;
	PnxLineBreak br = { end, end };
	return br;
}

int16_t pnx_text_lines_wrapped(const PnxFont* f, const char* s, int16_t w)
{
	if (!f || !s || !*s)
		return 0;

	int16_t lines = 0;
	for (const char* p = s; *p;)
	{
		const PnxLineBreak br = next_line(f, p, w);
		lines++;
		if (br.next == p)
			break; // cannot happen, but never loop on a bad font
		p = br.next;
	}
	return lines;
}

int16_t pnx_text_height_wrapped(const PnxFont* f, const char* s, int16_t w)
{
	if (!f)
		return 0;
	return (int16_t)(pnx_text_lines_wrapped(f, s, w) * f->line_height);
}

// ------------------------------------------------------------------------ drawing

int16_t pnx_text_draw(PnxTarget* t, const PnxFont* f, const char* s, int32_t x, int32_t y,
					  uint8_t colour)
{
	if (!t || !f || !s)
		return 0;

	const int32_t step = pen_sign(f->advance);
	int32_t pen, base;
	split_origin(f->advance, x, y, &pen, &base);

	const int32_t start = pen;
	for (const char* p = s; *p && *p != '\n'; p++)
	{
		PnxGlyph g;
		pnx_font_glyph(f, pnx_font_glyph_index(f, *p), &g);
		draw_glyph(t, f, &g, pen, base, colour);
		pen += step * g.advance;
	}
	// The advance CONSUMED, which is a length and never negative -- a caller chaining a
	// value after a label adds it to whichever coordinate its own text runs along.
	return (int16_t)((pen - start) * step);
}

// The dynamic 5-draw outline: 4 cardinal offsets in `outline_colour` behind a plain fill.
// Shared by pnx_text_draw_outlined and pnx_text_draw_gradient_outlined's own depth=1
// fallback, so the two never need to call one another.
static int16_t draw_outlined_dynamic(PnxTarget* t, const PnxFont* f, const char* s,
									 int32_t x, int32_t y, uint8_t fill_colour,
									 uint8_t outline_colour)
{
	// Cardinal offsets only (not the 4 diagonals too) -- a full 8-direction outline reads
	// barely thicker at this glyph size (12-20px) and doubles the draw cost for it; see
	// pnx_text_draw_outlined's own header comment on why 5x an already-cheap draw is fine
	// but 9x is the wrong trade for a HUD redrawn every tick.
	pnx_text_draw(t, f, s, x - 1, y, outline_colour);
	pnx_text_draw(t, f, s, x + 1, y, outline_colour);
	pnx_text_draw(t, f, s, x, y - 1, outline_colour);
	pnx_text_draw(t, f, s, x, y + 1, outline_colour);
	return pnx_text_draw(t, f, s, x, y, fill_colour);
}

int16_t pnx_text_draw_outlined(PnxTarget* t, const PnxFont* f, const char* s, int32_t x,
							   int32_t y, uint8_t fill_colour, uint8_t outline_colour)
{
	if (!t || !f || !s)
		return 0;

	// A depth=2 font already carries a baked outline ring per glyph -- one styled draw
	// reproduces the same silhouette the dynamic 5-offset trick approximates for a depth=1
	// font, cheaper and sharper (the ring follows the letterform instead of 4 cardinal
	// copies of it). fill_b just repeats fill_colour: this entry point offers only one fill
	// colour, same as it always has.
	if (f->depth == 2)
		return pnx_text_draw_gradient_outlined(t, f, s, x, y, outline_colour, fill_colour,
											   fill_colour);

	return draw_outlined_dynamic(t, f, s, x, y, fill_colour, outline_colour);
}

int16_t pnx_text_draw_gradient_outlined(PnxTarget* t, const PnxFont* f, const char* s,
										int32_t x, int32_t y, uint8_t outline_colour,
										uint8_t fill_a, uint8_t fill_b)
{
	if (!t || !f || !s)
		return 0;

	// No baked levels to draw from -- fall back to the dynamic 5-draw outline every
	// depth=1 font already has. fill_b has no meaning without baked levels, so it is
	// dropped rather than guessed at.
	if (f->depth != 2)
		return draw_outlined_dynamic(t, f, s, x, y, fill_a, outline_colour);

	const PnxTextPalette pal = { outline_colour, fill_a, fill_b };
	const int32_t step		 = pen_sign(f->advance);
	int32_t pen, base;
	split_origin(f->advance, x, y, &pen, &base);

	const int32_t start = pen;
	for (const char* p = s; *p && *p != '\n'; p++)
	{
		PnxGlyph g;
		pnx_font_glyph(f, pnx_font_glyph_index(f, *p), &g);
		draw_glyph_pal(t, f, &g, pen, base, &pal);
		pen += step * g.advance;
	}
	return (int16_t)((pen - start) * step);
}

int16_t pnx_text_draw_wrapped(PnxTarget* t, const PnxFont* f, const char* s, int32_t x,
							  int32_t y, int16_t w, int16_t h, uint8_t colour,
							  PnxTextAlign align)
{
	if (!t || !f || !s)
		return 0;

	const int32_t step	 = pen_sign(f->advance);
	const int32_t across = base_sign(f->advance);

	int16_t drawn = 0;
	int32_t pen_origin, baseline;
	split_origin(f->advance, x, y, &pen_origin, &baseline);
	const int32_t first_baseline = baseline;

	for (const char* p = s; *p;)
	{
		const PnxLineBreak br = next_line(f, p, w);

		// `h` bounds the box from the first baseline, so a caller sizing a dialogue box by
		// pnx_text_height_wrapped gets exactly the lines it measured. Measured along the
		// stacking direction, which is what makes the bound mean the same thing when lines
		// stack towards smaller coordinates.
		if (h > 0 && (baseline - first_baseline) * across >= h)
			break;

		int32_t start = pen_origin;
		if (align != PNX_ALIGN_LEFT)
		{
			const int16_t lw = width_range(f, p, br.end);
			const int16_t slack =
				(align == PNX_ALIGN_CENTER) ? (int16_t)((w - lw) / 2) : (int16_t)(w - lw);
			start += step * slack;
		}

		int32_t pen = start;
		for (const char* c = p; c < br.end; c++)
		{
			PnxGlyph g;
			pnx_font_glyph(f, pnx_font_glyph_index(f, *c), &g);
			draw_glyph(t, f, &g, pen, baseline, colour);
			pen += step * g.advance;
		}

		drawn++;
		baseline += across * f->line_height;
		if (br.next == p)
			break;
		p = br.next;
	}
	return drawn;
}

#endif // PNX_USE_TEXT
