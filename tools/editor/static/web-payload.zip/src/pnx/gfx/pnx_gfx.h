// Blitting and the camera.
//
// Everything draws through here, and everything here is 4bpp indexed: two pixels per
// byte, high nibble first, index 0 transparent in every palette. That last convention is
// load-bearing in the inner loop -- a transparent pixel is rejected on the index, before
// the palette is read and before the destination is touched.
//
// Clipping is done per row against the target's reported span rather than assumed, since
// the device's framebuffer can report a narrower valid range than its width.

#pragma once

#include "../pnx_config.h"
#include "../assets/pnx_assets.h"
#include "../core/pnx_fx.h"
#include "../platform/pnx_platform.h"

#include <stdint.h>
#include <stdbool.h>

// -------------------------------------------------------------------- 1-bit output
//
// Shared with pnx_text.c: a glyph blit and an indexed blit are different ways of deciding
// WHICH pixels to touch, but on a 1-bit target they write the SAME way once that decision
// is made, so both funnel through one rule rather than keeping two.
#if PNX_DISPLAY_BW
bool pnx_bw_is_ink(uint8_t colour);
void pnx_bw_set_pixel(uint8_t* row_data, int32_t x, bool ink);
#endif

// ------------------------------------------------------------------------ camera
//
// World coordinates are pixels, not tiles. Tile-sized steps make scrolling jerk at the
// tile boundary; pixels let the camera move smoothly and the tilemap simply starts its
// first column part-way off screen.

typedef struct
{
	int32_t x, y; // top-left of the view, in world pixels
	int16_t view_w, view_h;
} PnxCamera;

void pnx_camera_init(PnxCamera* c, int16_t view_w, int16_t view_h);

// Centres on a world point, then clamps so the view never leaves the world. Clamping
// here rather than at the call site is deliberate: every caller wants it, and forgetting
// it shows up as a strip of garbage at a map edge.
void pnx_camera_center(PnxCamera* c, int32_t wx, int32_t wy, int32_t world_w, int32_t world_h);

// ------------------------------------------------------------------------- blits

void pnx_gfx_clear(PnxTarget* t, uint8_t colour);

// Flip bits for pnx_blit_4bpp. X is 1 so an old `true` still means a horizontal flip.
#define PNX_FLIP_NONE 0
#define PNX_FLIP_X	  1
#define PNX_FLIP_Y	  2
// Transpose -- mirrors PNX_MAP_ROTATE (tools/pnx_assets.py / pnx_assets.h): swap rows and
// columns BEFORE flip_x/flip_y are applied. {rotate, flip_x, flip_y} together are the
// three independent bits spanning all 8 symmetries of a square (PNX_MAP_ROTATE's own
// comment has the enumeration) -- this bit is what makes that true at draw time too, not
// just in the format. Only meaningful when w == h: a tile is always square, so this is
// exactly the case pnx_tilemap.c ever passes it in. A caller drawing a non-square image
// (pnx_sprite.c, always) simply never sets it.
#define PNX_FLIP_ROTATE 4

// Blits a 4bpp image at a screen position. `mirror` flips horizontally, which is how a
// character faces left with no extra art -- the measured sprite sheets contain a walk
// cycle in one direction only.
//
// `src` is 4bpp indexed on a colour build and a ~bw resource (pack_unit_2bpp,
// tools/pnx_assets.py) on a 1-bit one -- one format per build (PNX_DISPLAY_BW), not a
// per-call choice, so the signature does not carry it. `palette` is read on a colour
// build and ignored on a 1-bit one, kept only so both builds share one call shape.
//
// PNX_FLIP_ROTATE costs the row-copy fast path the plain X/Y flips get (see pnx_gfx.c's
// own comment): a rotated destination row reads a source COLUMN, which is never
// contiguous, so every pixel is addressed individually regardless of what else `flip`
// carries. Still one blit, still no second buffer -- just the same per-pixel path
// PNX_FLIP_X already uses, with a different source index.
void pnx_blit_4bpp(PnxTarget* t, const uint8_t* src, const PnxPalette* palette, int32_t x,
				   int32_t y, int16_t w, int16_t h, uint8_t flip);

// Draws one metatiled tile: four 8x8 quadrants composed into a 16x16.
//
// Done as a single 16-row walk rather than four 8x8 blits. Four blits would double the
// per-row cost -- 32 row lookups and clip computations instead of 16 -- and row overhead
// is what dominates here: the measured frame cost fell 7,400 -> 5,100 us purely by
// reducing per-pixel and per-row work, not by changing what is drawn.
void pnx_blit_metatile(PnxTarget* t, const PnxAtlas* atlas, uint8_t tile, int32_t x, int32_t y);

// Same, with the palette supplied rather than looked up -- used for palette-swapped
// draws, and by tests that build an atlas without a loaded palette table.
void pnx_blit_metatile_with(PnxTarget* t, const PnxAtlas* atlas, uint8_t tile,
							const PnxPalette* palette, int32_t x, int32_t y);

// Filled rectangle in screen space, clipped. For dialog boxes and HUD panels.
void pnx_gfx_fill_rect(PnxTarget* t, int32_t x, int32_t y, int16_t w, int16_t h,
					   uint8_t colour);

// Same, but an ordered 1-pixel checkerboard between two colours instead of a solid
// fill -- a gradient built entirely from `pnx_gfx_fill_rect` bands is flat steps at
// this palette's resolution (2 bits/channel, 64 colours); alternating individual
// pixels between two adjacent steps reads as an intermediate shade instead, the same
// trick pixel art has always used to fake a bigger palette. The checkerboard parity
// is keyed off absolute (x, y), not rect-relative offsets, so two calls covering
// adjacent areas tile as one continuous pattern rather than each restarting its own
// phase at its own corner.
void pnx_gfx_fill_rect_dither(PnxTarget* t, int32_t x, int32_t y, int16_t w, int16_t h,
							  uint8_t colour_a, uint8_t colour_b);

// Blits an `sw` x `sh` window starting at `(sx, sy)` out of a larger 4bpp-packed source
// image whose own full width is `src_w` -- unrelated to the window being copied. This is
// what lets a 9-slice panel's corners/edges/centre be read out of ONE packed source image
// at draw time rather than pre-sliced into nine separate buffers at pack time.
//
// No `flip`: nothing that calls this needs to mirror a panel, and the simplest thing that
// could possibly need it does not exist yet -- see pnx_sprite.c, which never passes
// PNX_FLIP_ROTATE either. Trades pnx_blit_4bpp's paired-nibble fast path for a per-pixel
// loop; worth it here because a border region is small (an edge tile, a corner), never
// the whole-screen span pnx_blit_4bpp's fast path earns its keep on.
void pnx_blit_4bpp_region(PnxTarget* t, const uint8_t* src, int16_t src_w,
						  const PnxPalette* palette, int32_t x, int32_t y, int16_t sx,
						  int16_t sy, int16_t sw, int16_t sh);

// Blits a whole `src_w` x `src_h` 4bpp image, independently nearest-neighbor-scaling each
// axis to `dst_w` x `dst_h` -- the SNES/GBA-style "draw this sprite bigger/smaller" this
// engine has never had (pnx_nineslice.h's own header comment: "pnx_blit_4bpp has never
// scaled anything"). `src` uses the same flat-nibble-stream addressing pnx_blit_4bpp
// itself does (row N starts at nibble N*src_w, not byte (N*src_w)/2) rather than
// pnx_blit_4bpp_region's byte-per-row-stride convention -- this is what actual sprite
// frame data looks like, and getting it wrong here silently shears any frame whose
// authored width is odd, the same class of bug pnx_bitplane_decode's own history warns
// about.
//
// dst_w==src_w && dst_h==src_h dispatches straight to pnx_blit_4bpp: an unscaled caller
// pays nothing extra for this existing. Otherwise there is no fast paired-nibble path on
// the scaled axis/axes -- same per-pixel shape as pnx_blit_4bpp_region's mirrored/rotated
// siblings, because dest and source indices no longer walk in lockstep once a scale
// factor decouples them.
//
// No flip/rotate, no ~bw build (PNX_DISPLAY_BW) in v1 -- neither is needed by anything
// that calls this yet, and both are additive later, not a signature break.
#if !PNX_DISPLAY_BW
void pnx_blit_4bpp_scaled(PnxTarget* t, const uint8_t* src, const PnxPalette* palette,
						  int32_t x, int32_t y, int16_t src_w, int16_t src_h, int16_t dst_w,
						  int16_t dst_h);
#endif
